package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.cap.dao.impl.EmployeeDaoImpl;
import com.cap.model.Employee;

@RestController
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	private EmployeeDaoImpl employeeDao;

	@GetMapping(value = "/employees")
	public ResponseEntity<List<Employee>> getAllEmployees() {
		List<Employee> employees = employeeDao.getAllEmployee();

		if (employees == null || employees.isEmpty()) {
			return new ResponseEntity("No Data Found!", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(employees, HttpStatus.OK);
	}

	@PostMapping("/addEmployee")
	public ResponseEntity<Void> addEmployee(@RequestBody Employee emp,UriComponentsBuilder ucBuilder) {

		employeeDao.addEmployee(emp);
		return new ResponseEntity("Employee added !", HttpStatus.CREATED);

	}

	@PutMapping("/employees/{id}")
	public String updateEmployee(@PathVariable("id") Integer id, @RequestBody Employee emp) {
		
		employeeDao.updateEmployee(emp);
	
		return "updated sucessfully";
	}


	
	@RequestMapping(value = "/employees/{id}", method = RequestMethod.DELETE)
	public String deleteEmp(@PathVariable("id") Integer id){
		System.out.println();
		employeeDao.deleteEmployee(id);
		
		return "employee deleted sucessfully";
	}

	
}
