package com.cap.dao;

import java.util.List;

import com.cap.model.Employee;

public interface IEmployeeDao {
	
	//public Employee findEmployee(Integer id);
	public List<Employee> getAllEmployee();
	
	public void addEmployee(Employee emp);
	public void updateEmployee(Employee emp);
	public void deleteEmployee(Integer customerId);


}
