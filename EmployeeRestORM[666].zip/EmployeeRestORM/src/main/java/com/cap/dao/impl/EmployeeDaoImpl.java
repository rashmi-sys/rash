package com.cap.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cap.dao.IEmployeeDao;
import com.cap.model.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {

	@Autowired
	public HibernateTemplate hibernateTemplate;


	//@Override
	//public Employee findEmployee(Integer id) {

/*		for (Employee emp : employees) {
			if (emp.getEmployeeid() == id)
				return emp;
		}*/
		//return null;
	//}

	
	
	public List<Employee> getAllEmployee() {
		
		return null;
	}

	@Transactional
	public void addEmployee(Employee emp) {
		hibernateTemplate.save(emp);

	}

	public void updateEmployee(Employee emp) {
		hibernateTemplate.update(emp);
	}

	public void deleteEmployee(Integer customerId) {

	}

}
